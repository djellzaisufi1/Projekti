package UshtrimePerKollofium;

import java.awt.*;
import javax.swing.*;

public class MyGraphicsWindow extends JFrame {
   public MyGraphicsWindow() {
      setSize(400, 400);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setVisible(true);
   }

   public void paint(Graphics g) {
      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
      }

      g.setColor(Color.pink);
      g.fillRect(100, 100, 200, 200);

      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
      }

      g.setColor(Color.blue);
      g.fillOval(125, 125, 150, 150);

      try {
         Thread.sleep(2000);
      } catch (InterruptedException e) {
      }

      g.setColor(Color.black);
      g.drawLine(150, 200, 250, 300);
   }

   public static void main(String[] args) {
      new MyGraphicsWindow();
   }
}

